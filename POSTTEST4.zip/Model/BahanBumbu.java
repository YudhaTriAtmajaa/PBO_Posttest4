package Model;

public interface BahanBumbu {
    boolean isBumbu(); 
}
