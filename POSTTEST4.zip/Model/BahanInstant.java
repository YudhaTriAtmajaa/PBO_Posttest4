package Model;

public class BahanInstant extends Bahan implements BahanBumbu {
    private boolean halal;

    public BahanInstant(String nama, int stok, String satuan, String kadaluarsa, boolean halal) {
        super(nama, stok, satuan, kadaluarsa);
        this.halal = halal;
    }

    public boolean isHalal() { return halal; }
    public void setHalal(boolean halal) { this.halal = halal; }

    // Overriding
    @Override
    public String info() {
        return String.format("%-20s %-10d %-8s %-15s | Halal: %s",
                getNama(), getStok(), getSatuan(), getKadaluarsa(), (halal ? "Ya" : "Tidak"));
    }

    @Override
    public boolean isBumbu() {
        return true; // 
    }
}
