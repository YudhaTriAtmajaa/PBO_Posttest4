package Model;

public class BahanMinuman extends Bahan {
    private boolean berkarbonasi;

    public BahanMinuman(String nama, int stok, String satuan, String kadaluarsa, boolean berkarbonasi) {
        super(nama, stok, satuan, kadaluarsa);
        this.berkarbonasi = berkarbonasi;
    }

    public boolean isBerkarbonasi() { return berkarbonasi; }
    public void setBerkarbonasi(boolean berkarbonasi) { this.berkarbonasi = berkarbonasi; }

    // Overriding
    @Override
    public String info() {
        return String.format("%-20s %-10d %-8s %-15s | Berkarbonasi: %s",
                getNama(), getStok(), getSatuan(), getKadaluarsa(), (berkarbonasi ? "Ya" : "Tidak"));
    }
}
