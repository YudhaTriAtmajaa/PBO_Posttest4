package Service;

import Model.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Inventaris {
    private final ArrayList<Bahan> inventaris = new ArrayList<>();
    private final Scanner input = new Scanner(System.in);

    public Inventaris() {
        // Data awal bukan bumbu
        inventaris.add(new BahanInstant("Sarden", 10, "kg", "01-12-2025", true));
        inventaris.add(new BahanInstant("Spam", 30, "pcs", "20-09-2025", false));

        // Minuman
        inventaris.add(new BahanMinuman("Susu", 12, "liter", "15-11-2025", false));
        inventaris.add(new BahanMinuman("Cola", 20, "botol", "05-01-2026", true));
    }

    // ================= CREATE =================
    // versi input manual
    public void tambahBahan() {
        System.out.println("\n--- Tambah Bahan Baru ---");
        System.out.println("Pilih jenis bahan:");
        System.out.println("1. Bahan Instant");
        System.out.println("2. Bahan Minuman");
        int jenis = validasiAngka("Jenis (1-2): ");

        System.out.print("Nama Bahan          : ");
        String nama = input.nextLine();
        int stok = validasiAngka("Jumlah Stok         : ");
        System.out.print("Satuan (kg/liter/pcs): ");
        String satuan = input.nextLine();
        System.out.print("Tanggal Kadaluarsa  : ");
        String kadaluarsa = input.nextLine();

        switch (jenis) {
            case 1 -> {
                System.out.print("Apakah halal? (ya/tidak): ");
                boolean halal = input.nextLine().equalsIgnoreCase("ya");
                inventaris.add(new BahanInstant(nama, stok, satuan, kadaluarsa, halal));
            }
            case 2 -> {
                System.out.print("Apakah berkarbonasi? (ya/tidak): ");
                boolean karbonasi = input.nextLine().equalsIgnoreCase("ya");
                inventaris.add(new BahanMinuman(nama, stok, satuan, kadaluarsa, karbonasi));
            }
            default -> System.out.println("Jenis tidak valid, batal menambah bahan!");
        }
        System.out.println("Bahan berhasil ditambahkan!");
    }

    // overloading versi langsung parameter (bahan instant)
    public void tambahBahan(String nama, int stok, String satuan, String kadaluarsa, boolean halal) {
        inventaris.add(new BahanInstant(nama, stok, satuan, kadaluarsa, halal));
        System.out.println("Bahan Instant berhasil ditambahkan lewat parameter!");
    }

    // overloading versi langsung parameter (bahan minuman)
    public void tambahBahan(String nama, int stok, String satuan, String kadaluarsa, boolean karbonasi, boolean isMinuman) {
        inventaris.add(new BahanMinuman(nama, stok, satuan, kadaluarsa, karbonasi));
        System.out.println("Bahan Minuman berhasil ditambahkan lewat parameter!");
    }

    // ================= READ =================
    public void tampilInventaris() {
        System.out.println("\n--- Daftar Inventaris ---");
        if (inventaris.isEmpty()) {
            System.out.println("Inventaris masih kosong.");
        } else {
            for (int i = 0; i < inventaris.size(); i++) {
                Bahan b = inventaris.get(i);
                System.out.println((i + 1) + ". " + b.info());
            }
        }
    }

    // ================= UPDATE =================
    public void updateBahan() {
        tampilInventaris();
        if (inventaris.isEmpty()) return;

        int index = validasiAngka("Masukkan nomor bahan yang ingin diupdate: ");
        if (index > 0 && index <= inventaris.size()) {
            Bahan b = inventaris.get(index - 1);

            System.out.print("Nama Bahan baru          : ");
            b.setNama(input.nextLine());
            b.setStok(validasiAngka("Jumlah Stok baru         : "));
            System.out.print("Satuan baru (kg/liter/pcs): ");
            b.setSatuan(input.nextLine());
            System.out.print("Tanggal Kadaluarsa baru  : ");
            b.setKadaluarsa(input.nextLine());

            System.out.println("Bahan berhasil diperbarui!");
        } else {
            System.out.println("Nomor bahan tidak valid.");
        }
    }

    // ================= SEARCH =================
    // versi input manual
    public void cariBahan() {
        System.out.print("Masukkan nama bahan yang dicari: ");
        String keyword = input.nextLine();
        cariBahan(keyword); // panggil versi overloading
    }

    // versi overloading pakai parameter langsung
    public void cariBahan(String keyword) {
        keyword = keyword.toLowerCase();
        boolean ditemukan = false;

        for (Bahan b : inventaris) {
            if (b.getNama().toLowerCase().contains(keyword)) {
                System.out.println("Ditemukan: " + b.info());
                ditemukan = true;
            }
        }
        if (!ditemukan) {
            System.out.println("Bahan tidak ditemukan.");
        }
    }

    // ================= DELETE =================
    public void hapusBahan() {
        tampilInventaris();
        if (inventaris.isEmpty()) return;

        int index = validasiAngka("Masukkan nomor bahan yang ingin dihapus: ");
        if (index > 0 && index <= inventaris.size()) {
            inventaris.remove(index - 1);
            System.out.println("Bahan berhasil dihapus!");
        } else {
            System.out.println("Nomor bahan tidak valid.");
        }
    }

    // ================= VALIDASI =================
    private int validasiAngka(String pesan) {
        int angka;
        while (true) {
            try {
                System.out.print(pesan);
                angka = Integer.parseInt(input.nextLine());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Input harus berupa angka!");
            }
        }
        return angka;
    }
}
